// Baja de OpenStreetMap todas las canchas de golf de Argentina, con sus hoyos, greens y banderas,
// y las guarda en canchas-ar.json para que la app las tenga listas al instante.
// Lo corre GitHub una vez por semana (.github/workflows/canchas.yml). Sin dependencias: Node 20.
import { writeFileSync, readFileSync } from "node:fs";

const OUT = process.argv[2] || "canchas-ar.json";
const SERVERS = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
const QUERY = `[out:json][timeout:600];
area["ISO3166-1"="AR"][admin_level=2]->.a;
nwr["leisure"="golf_course"](area.a);
out tags geom;
way["golf"="hole"](area.a);
out tags geom;
(way["golf"="green"](area.a);relation["golf"="green"](area.a););
out tags geom;
node["golf"="pin"](area.a);
out;`;

async function download() {
  if (process.env.OVERPASS_FILE) return JSON.parse(readFileSync(process.env.OVERPASS_FILE, "utf8"));
  let last;
  for (const url of SERVERS) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const res = await fetch(url, { method: "POST", body: "data=" + encodeURIComponent(QUERY), headers: { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": "libreta-de-golf (GitHub Actions)" } });
        if (!res.ok) throw new Error("HTTP " + res.status);
        return await res.json();
      } catch (e) { last = e; await new Promise((r) => setTimeout(r, 20000)); }
    }
  }
  throw last;
}

const R = (v) => Math.round(v * 1e5) / 1e5;
const dist = (a, b) => { const k = Math.PI / 180, x = (b.lng - a.lng) * k * Math.cos((a.lat + b.lat) / 2 * k), y = (b.lat - a.lat) * k; return Math.hypot(x, y) * 6371000; };
const pts = (geom) => (geom || []).map((g) => ({ lat: g.lat, lng: g.lon }));
function rings(el) {
  if (el.geometry) return [pts(el.geometry)];
  if (el.members) return el.members.filter((m) => m.role !== "inner" && m.geometry).map((m) => pts(m.geometry));
  return [];
}
function inside(p, poly) {
  let ins = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.lat > p.lat) !== (b.lat > p.lat) && p.lng < (b.lng - a.lng) * (p.lat - a.lat) / (b.lat - a.lat) + a.lng) ins = !ins;
  }
  return ins;
}
const centroid = (poly) => ({ lat: poly.reduce((s, p) => s + p.lat, 0) / poly.length, lng: poly.reduce((s, p) => s + p.lng, 0) / poly.length });
const thin = (list, max) => list.length <= max ? list : Array.from({ length: max }, (_, k) => list[Math.round(k * (list.length - 1) / (max - 1))]);
const enc = (list) => list.map((p) => [R(p.lat), R(p.lng)]);

const data = await download();
const els = data.elements || [];
const courses = [], holes = [], greens = [], pins = [];
for (const e of els) {
  const t = e.tags || {};
  if (t.leisure === "golf_course" && t.name) {
    const rs = rings(e).filter((r) => r.length >= 3);
    const center = e.type === "node" ? { lat: e.lat, lng: e.lon } : rs.length ? centroid(rs.flat()) : null;
    if (center) courses.push({ key: e.type + "/" + e.id, name: t.name, place: t["addr:city"] || t["is_in:city"] || t["addr:state"] || "", rings: rs, center, holes: [] });
  } else if (t.golf === "hole" && e.geometry) {
    const line = pts(e.geometry);
    if (line.length >= 2) holes.push({ ref: parseInt(t.ref, 10), par: parseInt(t.par, 10) || null, sub: t["golf:course:name"] || "", line, mid: line[Math.floor(line.length / 2)] });
  } else if (t.golf === "green") {
    rings(e).filter((r) => r.length >= 3).forEach((r) => greens.push({ poly: r, c: centroid(r) }));
  } else if (t.golf === "pin" && e.type === "node") pins.push({ lat: e.lat, lng: e.lon });
}
// Cada hoyo va a la cancha que lo contiene (o a la más cercana, hasta 2 km)
for (const h of holes) {
  if (!h.ref) continue;
  let best = courses.find((c) => c.rings.some((r) => inside(h.mid, r)));
  if (!best) { let bd = 2000; for (const c of courses) { const d = dist(h.mid, c.center); if (d < bd) { bd = d; best = c; } } }
  if (best) best.holes.push(h);
}
const out = [];
for (const c of courses) {
  // Si un club tiene varias canchas (golf:course:name), cada una sale por separado
  const groups = new Map();
  for (const h of c.holes) { const k = h.sub; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(h); }
  if (!groups.size) groups.set("", []);
  for (const [sub, hs] of groups) {
    const byRef = new Map();
    hs.sort((a, b) => a.ref - b.ref).forEach((h) => { if (!byRef.has(h.ref)) byRef.set(h.ref, h); });
    const list = [...byRef.values()].map((h) => {
      const end = h.line[h.line.length - 1];
      let g = greens.find((x) => inside(end, x.poly));
      if (!g) { const near = greens.map((x) => ({ x, d: dist(end, x.c) })).sort((a, b) => a.d - b.d)[0]; if (near && near.d < 60) g = near.x; }
      const pin = g ? pins.find((p) => inside(p, g.poly)) : null;
      return { r: h.ref, p: h.par, l: enc(thin(h.line, 12)), g: g ? enc(thin(g.poly, 32)) : null, f: pin ? [R(pin.lat), R(pin.lng)] : null };
    });
    out.push({ k: c.key + (sub ? "#" + sub : ""), n: c.name + (sub ? " · " + sub : ""), c: c.place, la: R(c.center.lat), lo: R(c.center.lng), h: list });
  }
}
out.sort((a, b) => a.n.localeCompare(b.n, "es"));
writeFileSync(OUT, JSON.stringify({ fuente: "© OpenStreetMap (ODbL)", actualizado: new Date().toISOString().slice(0, 10), canchas: out }));
const withHoles = out.filter((c) => c.h.length >= 9).length;
console.log(`Listo: ${out.length} canchas, ${withHoles} con 9 o más hoyos dibujados -> ${OUT}`);
