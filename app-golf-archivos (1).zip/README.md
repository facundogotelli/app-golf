# Libreta de Golf

App de golf para registrar la ronda: tarjeta de score, distancia al green por GPS, yardas de cada tiro, historial y handicap estimado.

Este es el **prototipo web** (etapa 2 del plan del proyecto). Funciona desde el navegador del celular, sin instalar nada.

## Qué hace

- **Ronda de hasta 5 jugadores** (vos y 4 más) desde un solo celular: golpes y putts de cada uno, tarjeta con todos y resultado gross y neto al terminar.
- **Canchas argentinas:** lista de todas las canchas de Argentina en OpenStreetMap, ordenada por cercanía y con filtro. Al elegir una, la app trae hoyos, pares y el contorno de cada green; si no tiene hoyos en el mapa, abre la carga a mano con el nombre puesto.
- **Distancias:** al frente, la bandera y el fondo del green con el GPS del celular. Si la cancha no está en el mapa, el green se marca tocando el mapa satelital y la app lo recuerda.
- **Vista 3D:** el hoyo inclinado sobre el relieve real, del tee al green, con recorrido animado (satélite Esri y relieve libre, sin costo).
- **Video del tiro con trayectoria automática:** la app detecta el golpe por el sonido (o viendo cuándo la pelota deja el piso), encuentra la pelota, la sigue cuadro a cuadro y completa la parte que no se ve con un modelo de vuelo real (resistencia del aire, backspin y perspectiva de la cámara). Si no la encuentra, pide un toque sobre la pelota; queda el modo a mano como último recurso. Se puede guardar o compartir el video. Todo se procesa en el celular.
- **Tiros:** cada tiro registra tu posición y el palo; la distancia se calcula con la posición del tiro siguiente.
- **Estadísticas:** evolución del score y distancia promedio por palo.
- **Historial:** promedios de score, putts, fairways y greens en regulación, handicap estimado con la fórmula WHS y una comparación de cada ronda con lo esperado para tu handicap.

Los datos se guardan solo en el navegador del celular donde usás la app.

## Estructura

| Archivo | Para qué sirve |
|---|---|
| `index.html` | La app (es lo que publica GitHub Pages) |
| `canchas-ar.json` | Todas las canchas de Argentina de OpenStreetMap, con hoyos, greens y banderas. Lo genera GitHub solo cada lunes |
| `tarjetas.json` | Tarjetas oficiales de los clubes (par, handicap y yardas de cada hoyo; rating y slope de cada salida) |
| `tools/canchas.mjs` | El programa que baja las canchas de OpenStreetMap |
| `.github/workflows/canchas.yml` | La tarea semanal que corre ese programa y guarda `canchas-ar.json` |
| `supabase.sql` | La tabla para compartir tarjetas entre usuarios (se pega una vez en Supabase) |
| `src/app.html` y `build.sh` | El código de la app; `build.sh` arma `index.html` |

## Tarjetas

La app busca la tarjeta de cada cancha en este orden: la que cargó el usuario en su celular, la oficial del club (`tarjetas.json`) y la última compartida por otro usuario (Supabase). Con la tarjeta, el neto se calcula con el sistema WHS: handicap de cancha = índice × slope / 113 + (rating − par), y los golpes de ventaja se reparten según el handicap de cada hoyo.

Para activar las tarjetas compartidas hay que completar `SUPA = { url, key }` en `src/app.html` con la Project URL y la clave anon de Supabase.

## Datos

Canchas, hoyos y greens: © colaboradores de OpenStreetMap, licencia ODbL. Imágenes satelitales: Esri.
